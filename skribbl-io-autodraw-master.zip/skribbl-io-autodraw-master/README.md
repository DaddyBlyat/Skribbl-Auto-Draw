# skribbl-io-autodraw

Chrome extension that automatically draws images in pictionary game, [skribbl.io](https://skribbl.io/). Simply drag and drop an image on the canvas to initiate auto draw. Follow [these instructions](https://github.com/galehouse5/skribbl-io-autodraw/issues/2#issuecomment-414463698), courtesy of [@GlitchMasta47](https://github.com/GlitchMasta47), to install the extension.

![Drawing a Starfish](/drawing-a-starfish.gif)
